#include "ft_printf.h"

int main (void)
{
	ft_printf ("%07i", -54);	
	return 0;
}