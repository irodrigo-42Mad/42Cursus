#include "ft_printf.h"

int main (void)
{
	//printf("%-*.*s", -7, -3, "yolo");	
	ft_printf ("%-*.*s", -7, -3, "yolo");
	return 0;
}