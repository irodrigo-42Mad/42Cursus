#include "ft_printf.h"

int main (void)
{
	printf("%03i\n\n", 0);	
	ft_printf ("%03i", 0);
	return 0;
}