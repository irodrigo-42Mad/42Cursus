/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_prints.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/25 00:26:12 by irodrigo          #+#    #+#             */
/*   Updated: 2020/02/28 12:30:38 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

t_struct			*ft_prints(t_struct *my_temp)
{
	int		ln;
	int		i;
	char		*str;

	i = 0;
	str = va_arg(my_temp->args, char *);
	if (my_temp->precision > -1 && str)
		str = ft_strndup(str, my_temp->precision);
	else if (my_temp->precision == -1 && str)
		str = ft_strdup(str);
	else if (my_temp->precision > -1 && !str)
		str = ft_strndup("(null)", my_temp->precision);
	else if (my_temp->precision == -1 && !str)
		str= ft_strdup("(null)");
	ln = ft_strlen(str);
	my_temp->len += ln;
	if (my_temp->zero == 1 && my_temp->minus != 1)
		ft_draw(my_temp->f_width - ln, 1, '0', my_temp);
	else if (my_temp->minus != 1)
		ft_draw(my_temp->f_width - ln, 1, ' ', my_temp);
	ft_putstr(str);
	if (my_temp->minus == 1)
		ft_draw(my_temp->f_width - ln, 1, ' ', my_temp);
	free(str);
	return (my_temp);
}
