/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: irodrigo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/21 11:46:00 by irodrigo          #+#    #+#             */
/*   Updated: 2020/02/23 12:16:25 by irodrigo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_strcmp(const char *s1, const char *s2)
{
	int	i;

	i = 0;
	while (s1[i] && s2[i] && s1[i] == s2[i])
		++i;
	return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}

void	ft_putnbrmax_fd(intmax_t n, int fd)
{
	if (n == -9223372036854775807 - 1)
		write(1, "-9223372036854775808", 20);
	else
	{
		if (n < 0)
		{
			ft_putchar_fd('-', fd);
			n *= -1;
		}
		if (n > 9)
			ft_putnbrmax_fd(n / 10, fd);
		ft_putchar_fd((n % 10) + '0', fd);
	}
}

void	ft_putnbrumax_fd(uintmax_t n, int fd)
{
	if (n > 9)
		ft_putnbrumax_fd(n / 10, fd);
	ft_putchar_fd((n % 10) + '0', fd);
}
/*int	ft_strcmp(const char *s1, const char *s2)
{
	if (ft_strlen(s1) > ft_strlen(s2))
		return (ft_strncmp(s1, s2, (ft_strlen(s1))));
	return (ft_strncmp(s1, s2, (ft_strlen(s2))));
}*/

t_struct	*init(t_struct *temp)
{
	temp->len = 0;
	temp->i = 0;
	temp->arg_flags[0] = '\0';
	temp->arg_flags[1] = '\0';
	temp->arg_mask = ARGV_MASK;
	temp->s_mask = SPEC_MASK;
	temp->precision = -1;
	temp->plus = 0;
	temp->minus = 0;
	temp->zero = 0;
	temp->space = 0;
	temp->star = 0;
	temp->f_width = 0;

	/*
	values->converter_mask = CONV_MODF;
	values->f_treat = (char *)values->m_format;*/
	temp->f_copy = (char *)temp->m_format;
	return (temp);
}
