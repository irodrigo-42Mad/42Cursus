# 42madrid_3dgame
Una réplica en 3D del famoso juego del dinosaurio de Google Chrome.

## Primeros pasos
Existen muchos canales y blogs dedicados al desarrollo de videojuegos con Unity. No obstante, lo más recomendable para "romper el hielo" es revisar el apartado de tutoriales de la página oficial de Unity.

[https://learn.unity.com](https://learn.unity.com/tutorials/?k=%5B"lang%3Aen"%2C"prm%3Anone_premium"%5D&ob=starts)

## Canales de interés
[Brackeys](https://www.youtube.com/user/Brackeys)

[Blackthornprod](https://www.youtube.com/channel/UC9Z1XWw1kmnvOOFsj6Bzy2g)

[Dani](https://www.youtube.com/channel/UCIabPXjvT5BVTxRDPCBBOOQ)

[GameDevHQ](https://www.youtube.com/user/Unity3DCoder)

[Sebastian Lague](https://www.youtube.com/user/Cercopithecan)

## Páginas de interés
[Opengameart.org](https://opengameart.org/) - Una buena fuente de recursos gratuitos (sonidos, imagenes, modelos...)

[itch.io](https://itch.io/) - Un lugar donde compartir juegos indie

## Game Dev Week
Link del proyecto 2D realizado por Carlos López

[https://github.com/CarlosLop94/42madrid-gamejam2D](https://github.com/CarlosLop94/42madrid-gamejam2D)

